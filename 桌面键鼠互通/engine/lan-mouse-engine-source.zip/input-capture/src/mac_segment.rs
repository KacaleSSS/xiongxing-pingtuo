pub fn crossed(side:u8, [l,t,r,b]:[f64;4], [x,y]:[f64;2], [dx,dy]:[f64;2], lo:f64,hi:f64)->bool{
        let (axis,out)=match side {
            0=>((y-t)/(b-t),dx<0. && x>=l && x<=l+1.),
            1=>((y-t)/(b-t),dx>0. && x>=r-1. && x<=r),
            2=>((x-l)/(r-l),dy<0. && y>=t && y<=t+1.),
            3=>((x-l)/(r-l),dy>0. && y>=b-1. && y<=b),
            _=>return false,
        };
        out && axis>=lo && axis<hi
}
#[cfg(test)]
mod tests{
 use super::*;
 #[test] fn only_configured_side_segment(){
     let b=[0.,0.,1200.,800.];
     assert!(crossed(3,b,[500.,799.],[0.,2.],0.3,0.7));
     assert!(!crossed(3,b,[200.,799.],[0.,2.],0.3,0.7));
     assert!(!crossed(3,b,[500.,799.],[0.,-2.],0.3,0.7));
     assert!(!crossed(3,b,[500.,400.],[0.,500.],0.3,0.7));
     assert!(crossed(0,b,[0.,300.],[-2.,0.],0.25,0.5));
     assert!(!crossed(0,b,[0.,400.],[-2.,0.],0.25,0.5));
 }
}
